/**
 * JPA domain objects.
 */
package org.weightcars.domain;
