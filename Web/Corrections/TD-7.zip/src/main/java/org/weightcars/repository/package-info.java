/**
 * Spring Data JPA repositories.
 */
package org.weightcars.repository;
