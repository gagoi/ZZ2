void init_by_array(unsigned long init_key[], int key_length);
double genrand_real1(void);