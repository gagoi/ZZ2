package picasso;

import javafx.concurrent.Task;
import javafx.scene.Group;

public class TaskPicassoCalculator extends Task<Group>{
	/** largeur de la toile */
	private int width;
	
	/** hauteur de la toile */
	private int height;
	
	/**
	 * Constructeur
	 * @param inWidth largeur de la toile
	 * @param inHeight hauteur de la toile
	 */
	public TaskPicassoCalculator(int inWidth, int inHeight) {
		width = inWidth;
		height= inHeight;
	}
	
	@Override
	/**
	 * action de la tache
	 */
	protected Group call() throws Exception {
		return null; // a completer
	}
}
